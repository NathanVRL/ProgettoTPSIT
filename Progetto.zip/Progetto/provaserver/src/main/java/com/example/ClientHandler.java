
package com.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class ClientHandler extends Thread {
    private static int contatore = 0;
    private int id;
    private Socket s;
    private List<ClientHandler> clients;
    private PrintWriter out = null;
    private BufferedReader in = null;
    private String hostname = null;

    public ClientHandler(Socket s, List<ClientHandler> clients) {
        contatore++;
        this.id = contatore;
        this.s = s;
        this.clients = clients;

        try {
             in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            out = new PrintWriter(s.getOutputStream(), true);
   
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {

    //crezioni variabili    
        String sessione ="";
        boolean ciclo = true;

        try {   
        //inserimento del hostname
            out.println("inserire il tuo hostname ");
            hostname = in.readLine();
            System.out.println("il nome del client numero "+ id +" ha come hostname " + hostname);


        //ricezzione tabella se vuole essere publico o privato la connesione
            

                sessione = in.readLine();
                System.out.println(sessione);
                //sessione privata
                if (sessione.equalsIgnoreCase("privato")){
                   while(ciclo){
                    out.println("scrivi il nome della persona a cui vuoi inviare un messagio");
                    String destinatario=in.readLine(); 
                    out.println("scrivi il messagio");
                    String msg=in.readLine(); 
                    invioSingolo(destinatario, msg);
                   }


                }//sessione publica
                else if (sessione.equalsIgnoreCase("publico")) {
                
                    out.println("sei in publico ora puoi mandare messagi tra tutti i nostri fra");
                    out.println("se vuoi uscire scrivi:esci da chat");
                    out.println("inserire cosa vuore dire hai fra");

                   while(ciclo){
                        String messagio=in.readLine(); 
                        if(messagio.equalsIgnoreCase("esci da chat")){
                            ciclo=false;
                        }
                        sendToAll(messagio);
                    
                    }    
                   
                }//uscita dalla sessio
                else if (sessione.equalsIgnoreCase("uscire")) {
                    
                    out.println("Addio ti ho voluto pene mon amour");
                    sendToAll("@");
                    ciclo = false;


                }
                else{

                    out.println("Non è valido questo comando");

                }
        
        } catch (Exception e) {
       
        }
    }

    private void sendToAll(String msg) {
        for (ClientHandler client : clients) {
            System.out.println(client.getName());
            client.out.println(msg);
            
        }
    }
    private void invioSingolo(String destinatario,String msg) {
        for(int i=0;i<clients.size();i++){
            if(clients.get(i).getHostname().equalsIgnoreCase(destinatario)){
                clients.get(i).out.println(msg);
            }
        }
    }


    public Socket getS() {
        return s;
    }

    public String getHostname() {
        return hostname;
    }



}
