package com.example;
public class MessagioMaranzone {
    
    private String mitente; 
    private String destinatario;
    private String messagio;

    public MessagioMaranzone(String mitente, String destinatario) {
        this.mitente = mitente;
        this.destinatario = destinatario;
        messagio=null;
    }

    public String getMitente() {
        return mitente;
    }

    public void setMitente(String mitente) {
        this.mitente = mitente;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public String getMessagio() {
        return messagio;
    }

    public void setMessagio(String messagio) {
        this.messagio = messagio;
    }
    
    

}